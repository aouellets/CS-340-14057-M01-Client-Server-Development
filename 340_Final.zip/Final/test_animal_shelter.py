from animal_shelter import AnimalShelter

# MongoDB credentials
username = "aacuser"           # Replace with your username
password = "YourSecurePassword"  # Replace with your password

# Initialize AnimalShelter class
try:
    print("Initializing MongoDB connection...")
    shelter = AnimalShelter(username, password)
    print("MongoDB connection established successfully!")
except Exception as e:
    print(f"Error initializing MongoDB connection: {e}")
    exit()

# Test data for CRUD operations
test_dog = {
    "animal_id": "A123456",
    "animal_type": "Dog",
    "breed": "Golden Retriever",
    "color": "Golden",
    "date_of_birth": "2020-01-01",
    "outcome_type": "Adoption",
    "outcome_subtype": None,
    "age_upon_outcome": "2 years"
}

# Testing Create Method
print("\nTesting Create Method:")
try:
    create_success = shelter.create(test_dog)
    print(f"Create Successful: {create_success}")
except Exception as e:
    print(f"Error during Create Test: {e}")

# Testing Read Method
print("\nTesting Read Method:")
try:
    query = {"breed": "Golden Retriever"}
    results = shelter.read(query)
    print(f"Number of Results: {len(results)}")
    for result in results:
        print(result)
except Exception as e:
    print(f"Error during Read Test: {e}")

# Testing Update Method
print("\nTesting Update Method:")
try:
    query = {"animal_id": "A123456"}
    new_values = {"color": "Golden Brown"}
    updated_count = shelter.update(query, new_values)
    print(f"Number of Documents Updated: {updated_count}")
except Exception as e:
    print(f"Error during Update Test: {e}")

# Testing Delete Method
print("\nTesting Delete Method:")
try:
    query = {"animal_id": "A123456"}
    deleted_count = shelter.delete(query)
    print(f"Number of Documents Deleted: {deleted_count}")
except Exception as e:
    print(f"Error during Delete Test: {e}")

# Reset test data (optional)
print("\nResetting test data...")
try:
    shelter.create(test_dog)
    print("Test data reset successfully.")
except Exception as e:
    print(f"Error resetting test data: {e}")

