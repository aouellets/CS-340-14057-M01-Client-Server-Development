from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password):
        """Initialize MongoDB connection"""
        try:
            self.username = username
            self.password = password
            self.host = "nv-desktop-services.apporto.com"
            self.port = 31580
            self.db_name = "AAC"

            # Establish connection
            print("Initializing MongoDB connection...")
            self.client = MongoClient(
		    f"mongodb://{self.username}:{self.password}@nv-desktop-services.apporto.com:32941/AAC?authSource=AAC",
		    serverSelectionTimeoutMS=5000
	    )

            self.database = self.client[self.db_name]
            self.collection = self.database["animals"]
            print("Connected to MongoDB successfully.")
        except Exception as e:
            print(f"Error initializing MongoDB connection: {e}")
            raise

    def create(self, data):
        """Create a document in the database"""
        try:
            if data is not None:
                print(f"Attempting to insert data: {data}")
                result = self.collection.insert_one(data)
                print(f"Insert result: {result.acknowledged}")
                return result.acknowledged
            else:
                raise ValueError("Data is empty. Cannot insert.")
        except Exception as e:
            print(f"Error inserting document: {e}")
            return False

    def read(self, query):
        """Read documents from the database"""
        try:
            if query is not None:
                print(f"Attempting to read with query: {query}")
                result = list(self.collection.find(query))
                print(f"Read result: {len(result)} documents found.")
                return result
            else:
                raise ValueError("Query is empty. Cannot read.")
        except Exception as e:
            print(f"Error querying documents: {e}")
            return []

    def update(self, query, new_values):
        """Update documents in the database"""
        try:
            if query and new_values:
                print(f"Attempting to update documents with query: {query}, new values: {new_values}")
                result = self.collection.update_many(query, {"$set": new_values})
                print(f"Update result: {result.modified_count} documents updated.")
                return result.modified_count
            else:
                raise ValueError("Query or new values are empty. Cannot update.")
        except Exception as e:
            print(f"Error updating documents: {e}")
            return 0

    def delete(self, query):
        """Delete documents from the database"""
        try:
            if query:
                print(f"Attempting to delete documents with query: {query}")
                result = self.collection.delete_many(query)
                print(f"Delete result: {result.deleted_count} documents deleted.")
                return result.deleted_count
            else:
                raise ValueError("Query is empty. Cannot delete.")
        except Exception as e:
            print(f"Error deleting documents: {e}")
            return 0

